import React from 'react';
// import 'bootstrap/dist/css/bootstrap.min.css';
import Card from './Component/Card.jsx'
import Sdata from './Component/Sdata.jsx';



const App = () => {
    return (
        <>

            {Sdata.map((val) => {
                return (

                    <Card title={val.title} img={val.img} link={val.link}  />
                    
                )
            })};

            {/* 
             <div class="container text-center">
                <div class="row">
                    
                    <div class="col">
                        <Card title={Sdata[0].title} img={Sdata[0].img}  />
                    </div>
                    <div class="col">
                        <Card title={Sdata[1].title} img={Sdata[1].img}  />
                    </div>
                    <div class="col">
                        <Card title={Sdata[2].title} img={Sdata[2].img} link={Sdata[2].link} />
                    </div>
                    
                </div>
            </div>  */}
        </>
    );
}

export default App;
