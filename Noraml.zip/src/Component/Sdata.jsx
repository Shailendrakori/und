

const Sdata=[

    { 
        title: "Kgf 3",
        img: require("../img/kgf.jpg"),  

    },
    {
        title:"Dhoom",
        img:require("../img/dhoom2.jpeg") 
    },
    { 
        title:"krish",
        img:require("../img/krish.jpg"),
        link:"https://www.youtube.com/watch?v=XLM3T953tvc"
    }
]
export default Sdata